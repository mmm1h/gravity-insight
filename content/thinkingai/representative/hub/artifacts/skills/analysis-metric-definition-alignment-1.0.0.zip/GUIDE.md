# Project metric contract check

Use when a project metric must be resolved to an exact definition and physical binding before any observed value is interpreted.

1. Resolve the exact project metric URI for the requested App and date window.
2. Check owner, unit, aggregation, time grain, formula dependencies, binding, and effective range.
3. Stop before product selection when the definition or binding is missing, conflicting, or outside its effective range.
4. After resolution, use the existing event-analysis product and report only returned observations under that contract.

Project Semantic sources are authoritative data contracts; prose and field names cannot substitute for a missing definition or binding.
