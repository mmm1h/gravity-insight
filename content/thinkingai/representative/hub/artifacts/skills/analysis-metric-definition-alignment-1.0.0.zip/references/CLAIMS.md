# Claim Policy

## Allowed

- `returned-event-metric-observation`

## Forbidden

- `inferred-metric-definition`
- `causality`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
