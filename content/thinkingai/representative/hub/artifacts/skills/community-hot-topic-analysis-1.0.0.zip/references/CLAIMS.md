# Claim Policy

## Allowed

- `returned-event-metric-observation`
- `context-supported-association`

## Forbidden

- `causality`
- `instruction-authority`

## Forbidden Without Context

- `context-supported-association`
