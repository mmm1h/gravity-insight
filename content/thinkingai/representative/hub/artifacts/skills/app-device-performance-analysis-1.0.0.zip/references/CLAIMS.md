# Claim Policy

## Allowed

- `returned-event-metric-observation`

## Forbidden

- `complete-device-population`
- `causality`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
