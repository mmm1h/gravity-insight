# Returned-filter comparison

Use when the same exact metric can be compared across explicit filter selections or windows and only returned rows need evaluation.

1. Freeze one event definition, metric, grouping, unit, and comparison scope.
2. Execute through the existing event-analysis owner and preserve completeness and data-quality state for each result.
3. Apply the registered returned-dimension-change Operator only when its row, unit, additivity, and cross-check assumptions hold.
4. Report matched returned-key changes and excluded rows; do not infer the unreturned population or a causal filter effect.

No narrative context can change Operator inputs, assumptions, cross-checks, or the prohibition on unreturned and causal claims.
