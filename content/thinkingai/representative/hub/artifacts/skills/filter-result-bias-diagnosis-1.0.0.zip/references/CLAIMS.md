# Claim Policy

## Allowed

- `returned-event-metric-observation`
- `returned-dimension-change`

## Forbidden

- `complete-population`
- `causality`
- `unreturned-values`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
