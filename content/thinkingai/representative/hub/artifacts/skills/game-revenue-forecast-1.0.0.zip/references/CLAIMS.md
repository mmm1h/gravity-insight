# Claim Policy

## Allowed


## Forbidden

- `unvalidated-revenue-forecast`
- `invented-confidence`
- `causality`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
