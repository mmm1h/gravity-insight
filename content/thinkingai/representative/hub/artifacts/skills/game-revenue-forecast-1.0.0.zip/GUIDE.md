# Revenue forecast readiness

Use to determine whether current observations and an exact validated model are sufficient for a bounded forecast; without that model the result is a gap only.

1. Verify the business-pulse capability and preserve its completeness and data-quality limits.
2. Resolve the exact model URI and verify trusted distribution, lineage, evaluation, approval, expiry, and safe horizon.
3. Stop with a model gap when any model requirement is absent; do not estimate a replacement with prompt reasoning.
4. When a future approved model exists, distinguish observed inputs, scenario assumptions, estimates, and validation limits.

Narrative plans and vendor examples are not model artifacts, validation evidence, forecast inputs, or authorization to publish a prediction.
