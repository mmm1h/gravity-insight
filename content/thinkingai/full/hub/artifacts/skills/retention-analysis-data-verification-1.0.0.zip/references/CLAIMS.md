# Claim Policy

## Allowed


## Forbidden

- `causality`
- `complete-cohort-population`
- `inferred-retention-definition`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
