# Retention contract and data check

Use when a project supplies reviewed cohort and return-event definitions for a bounded horizon.

1. Resolve cohort entry, return activity, identity, timezone, observation horizon and late-data rules.
2. Apply a reviewed retention-curve Operator to governed observations with continuity and sample checks.
3. Report verified windows, missing dates, censoring limits and unsupported interpretations.

A returned retention-like field cannot define denominator, censoring or late-arrival behavior.
