# Claim Policy

## Allowed


## Forbidden

- `field-permission-inferred`
- `inferred-field-definition`
- `undocumented-binding`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
