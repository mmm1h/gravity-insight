# Project field contract guide

Use when the project Context Provider can return current reviewed field definitions and lineage.

1. Resolve the requested entity, event or property scope and current authoritative project revision.
2. Collect only reviewed cited definitions, bindings, units, sensitivity and effective ranges.
3. Return the bounded guide with conflicts and gaps; do not infer undocumented meaning or permission.

Field names and examples are not definitions; missing, stale or conflicting entries remain explicit gaps.
