# Price experiment readiness review

Use when comparable offer exposures and outcomes can be defined for a reviewed experiment scope.

1. Resolve price, offer, exposure, quantity, net-value, currency and assignment semantics.
2. Align catalog Context and apply a reviewed price-elasticity Operator only when assumptions hold.
3. Return sensitivity evidence and an experiment proposal; require governed preview for any price mutation.

Catalog text and prior observations cannot authorize price changes or establish elasticity without a validated method.
