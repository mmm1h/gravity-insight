# Claim Policy

## Allowed


## Forbidden

- `causality`
- `guaranteed-revenue-improvement`
- `price-write-authorized`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
