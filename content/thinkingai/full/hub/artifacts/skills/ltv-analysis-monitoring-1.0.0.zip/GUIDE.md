# LTV observation and model health review

Use when currency, net-value, cohort and model-version bindings are reviewed.

1. Resolve cohort, net-value, currency, refund, horizon and attribution semantics.
2. Verify the exact LTV Model lineage, calibration window, approval, expiry and monitoring thresholds.
3. Separate observed value, model estimates, drift evidence and unresolved coverage limitations.

Observed revenue is not automatically LTV, and model drift cannot be inferred without registered evaluation evidence.
