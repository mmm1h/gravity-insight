# Claim Policy

## Allowed


## Forbidden

- `causality`
- `invented-confidence`
- `unvalidated-future-value`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
