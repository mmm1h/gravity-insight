# Claim Policy

## Allowed


## Forbidden

- `access-authorized`
- `credential-availability`
- `unregistered-route-support`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
