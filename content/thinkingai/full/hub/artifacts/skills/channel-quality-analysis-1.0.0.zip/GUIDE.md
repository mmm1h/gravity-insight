# Channel evidence quality review

Use when a project has reviewed channel identity, cost and downstream-value semantics for the same cohort window.

1. Resolve channel identity, acquisition-cost and downstream-value definitions for one cohort scope.
2. Compare matched returned channel rows while preserving missing, partial and unknown completeness states.
3. Report observable quality signals, excluded channels and the evidence still required for an allocation decision.

Channel labels and attribution windows cannot be inferred from result fields, and descriptive differences do not establish channel causality.
