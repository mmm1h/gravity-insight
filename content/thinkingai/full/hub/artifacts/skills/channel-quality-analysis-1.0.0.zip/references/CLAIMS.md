# Claim Policy

## Allowed


## Forbidden

- `causality`
- `complete-channel-population`
- `optimal-budget-allocation`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
