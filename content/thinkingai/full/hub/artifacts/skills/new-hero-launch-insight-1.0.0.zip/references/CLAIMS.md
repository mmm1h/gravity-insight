# Claim Policy

## Allowed


## Forbidden

- `causality`
- `complete-player-population`
- `launch-incrementality`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
