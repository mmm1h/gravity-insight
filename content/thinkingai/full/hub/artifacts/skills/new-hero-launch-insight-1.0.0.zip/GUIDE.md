# New content launch evidence review

Use for one project content launch with exact entity, release and observation-window definitions.

1. Resolve content identity, eligible population, release window and approved engagement/value metrics.
2. Align release Context with governed returned observations and preserve completeness and quality limits.
3. Report temporal associations, excluded concurrent changes and hypotheses without causal attribution.

Release notes establish timing and scope only; they do not prove that the launch caused behavior changes.
