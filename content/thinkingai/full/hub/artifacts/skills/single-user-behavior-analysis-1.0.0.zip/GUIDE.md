# Authorized single-subject event review

Use only for an explicitly authorized subject and date scope under the project's identity policy.

1. Resolve the authorized subject identity, purpose, date window and minimum allowed event fields.
2. Query only the exact governed returned event scope and preserve projection, privacy and completeness limits.
3. Describe the returned sequence and gaps without identity expansion, intent inference or population claims.

Identifiers, missing events and free-text fields cannot be joined or interpreted beyond the reviewed identity and privacy contract.
