# Claim Policy

## Allowed


## Forbidden

- `complete-user-history`
- `hidden-identity-linkage`
- `user-intent`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
