# Value payback readiness assessment

Use to assess readiness for a bounded cohort and acquisition channel.

1. Resolve acquisition cost, cohort, net-value, currency, attribution and observation-horizon semantics.
2. Verify the exact payback Model lineage, calibration, approval, expiry and safe horizon.
3. Stop on missing compatibility; otherwise report scenario assumptions and estimate limitations separately.

Observed early revenue and spend do not determine future payback without a validated horizon and model.
