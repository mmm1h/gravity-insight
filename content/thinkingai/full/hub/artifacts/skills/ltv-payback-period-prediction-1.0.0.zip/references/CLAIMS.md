# Claim Policy

## Allowed


## Forbidden

- `causality`
- `guaranteed-payback-date`
- `invented-confidence`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
