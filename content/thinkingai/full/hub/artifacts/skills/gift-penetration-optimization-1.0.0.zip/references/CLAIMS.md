# Claim Policy

## Allowed


## Forbidden

- `causality`
- `complete-eligible-population`
- `optimal-offer-design`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
