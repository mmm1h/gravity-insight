# Gift offer reach decomposition

Use when the project defines the eligible base, offer exposure, purchase and refund semantics.

1. Resolve eligible population, offer exposure, qualifying purchase and refund definitions.
2. Apply a reviewed decomposition Operator to compatible returned counts and units.
3. Report observed component gaps and testable hypotheses without causal or unreturned-population claims.

Returned reach cannot reveal unobserved eligibility or prove that an offer change would improve purchase behavior.
