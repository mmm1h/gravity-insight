# LTV dashboard artifact proposal

Use to prepare a target-neutral dashboard proposal for reviewed value observations and estimates.

1. Resolve project LTV, cohort, currency, horizon and model-version semantics.
2. Define a target-neutral Analysis Artifact with sources, filters, limitations and allowed claims.
3. Require a separate governed dashboard preview, user authorization and readback before any target change.

The specification cannot create a dashboard, invent model outputs or authorize a target-system write.
