# Claim Policy

## Allowed


## Forbidden

- `dashboard-write-authorized`
- `invented-confidence`
- `unvalidated-future-value`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
