# Claim Policy

## Allowed


## Forbidden

- `automatic-contact-authorized`
- `causality`
- `guaranteed-offer-response`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
