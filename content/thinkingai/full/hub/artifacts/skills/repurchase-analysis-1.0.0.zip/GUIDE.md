# Repeat-purchase cohort observation

Use for a bounded cohort with reviewed purchase history and repeat-window definitions.

1. Resolve qualifying order, refund, currency, user identity, cohort and repeat-window semantics.
2. Query governed returned purchase events and group only by approved cohort dimensions.
3. Report observed repeat behavior and history gaps without complete-lifetime or causal claims.

Incomplete history cannot establish first or repeat purchase status, and returned differences do not prove motivation.
