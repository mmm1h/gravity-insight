# Claim Policy

## Allowed


## Forbidden

- `causality`
- `complete-lifetime-history`
- `purchase-motivation`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
