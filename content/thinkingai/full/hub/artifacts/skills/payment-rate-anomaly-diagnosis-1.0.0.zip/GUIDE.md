# Payment-rate anomaly localization

Use for two bounded windows when numerator and denominator semantics are compatible and reviewed.

1. Resolve payment numerator, eligible denominator, timezone, cohort and attribution semantics.
2. Use the registered anomaly product to compare compatible returned windows and dimensions.
3. Report observed metric and contribution changes, excluded factors and hypotheses within allowed claims.

A field named payment rate is not a definition; returned dimension changes do not prove root cause or full coverage.
