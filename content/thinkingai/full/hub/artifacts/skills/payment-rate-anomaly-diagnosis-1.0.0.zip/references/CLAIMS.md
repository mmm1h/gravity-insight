# Claim Policy

## Allowed


## Forbidden

- `causality`
- `complete-payment-population`
- `inferred-metric-definition`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
