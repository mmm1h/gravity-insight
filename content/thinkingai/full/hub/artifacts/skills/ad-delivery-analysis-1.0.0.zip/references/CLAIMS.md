# Claim Policy

## Allowed


## Forbidden

- `causality`
- `complete-channel-population`
- `incremental-return`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
