# Bounded acquisition delivery review

Use for a bounded channel or campaign window when the project owns the acquisition metric bindings.

1. Resolve project spend and acquisition-outcome semantics for the selected window and platform.
2. Use the registered anomaly product to compare only matched returned dimensions with preserved completeness and quality.
3. Separate observed delivery movement from attribution assumptions, excluded channels and causal hypotheses.

Campaign names, budgets and attribution rules are project data; absent bindings stop the review and no returned association proves incrementality.
