# Claim Policy

## Allowed


## Forbidden

- `database-change-authorized`
- `production-performance-guarantee`
- `sql-execution-authorized`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
