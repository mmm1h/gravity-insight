# Claim Policy

## Allowed


## Forbidden

- `causality`
- `complete-lifetime-history`
- `unreturned-user-behavior`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
