# First-purchase cohort observation

Use for a bounded cohort when the project has a reviewed first-purchase semantic binding.

1. Resolve qualifying order, refund, currency, user identity and cohort-window semantics.
2. Query the exact returned event metric and group only by approved cohort dimensions.
3. Report returned cohort observations and history gaps without claiming complete lifetime-first coverage.

A returned order is not automatically a qualifying first purchase, and missing history prevents lifetime-first claims.
