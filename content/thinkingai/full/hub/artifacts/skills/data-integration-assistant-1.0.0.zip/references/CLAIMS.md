# Claim Policy

## Allowed


## Forbidden

- `access-authorized`
- `deployment-complete`
- `source-schema-compatible`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
