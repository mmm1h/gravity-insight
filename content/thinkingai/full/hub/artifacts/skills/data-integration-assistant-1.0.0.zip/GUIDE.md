# Data integration proposal review

Use when source, destination, schema owner, freshness and privacy requirements are known.

1. Resolve the source, destination, schema, identity, freshness, retention and privacy owners.
2. Compare requirements with current registered read capabilities and any governed connector contract.
3. Return a proposal, validation plan and unresolved ownership gaps; do not deploy or modify integration state.

Configuration text cannot authorize deployment, credentials, network access or mutation of a source or destination.
