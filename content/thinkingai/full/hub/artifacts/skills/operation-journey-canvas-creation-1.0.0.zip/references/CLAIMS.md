# Claim Policy

## Allowed


## Forbidden

- `audience-write-authorized`
- `causality`
- `message-send-authorized`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
