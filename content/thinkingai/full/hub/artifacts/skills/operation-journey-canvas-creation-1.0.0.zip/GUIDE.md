# Governed operations journey proposal

Use when the project owns audience semantics, channel policy, cadence and guardrail definitions.

1. Resolve objective, eligibility, exclusions, contact policy, cadence, exit criteria and guardrail metrics.
2. Model the journey as a value-free proposal with measurement and conflict checks.
3. Require a separate governed connector preview, explicit user authorization and readback for every mutation.

Strategy documents cannot authorize audience mutation, message delivery or scheduling in an external system.
