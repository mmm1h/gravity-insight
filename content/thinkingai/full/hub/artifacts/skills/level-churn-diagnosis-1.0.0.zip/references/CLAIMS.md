# Claim Policy

## Allowed


## Forbidden

- `causality`
- `complete-player-progression`
- `player-intent`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
