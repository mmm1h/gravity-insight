# Level progression loss diagnosis

Use for a bounded progression range with reviewed event and cohort semantics.

1. Resolve level identity, exposure, entry, completion, retry and churn-window semantics.
2. Apply a reviewed funnel-diagnosis Operator to governed returned progression steps.
3. Report returned loss points, excluded cohorts and hypotheses without attributing player intent or design causality.

A level with fewer returned completions is not automatically difficult or causal; missing exposure and eligibility stop that claim.
