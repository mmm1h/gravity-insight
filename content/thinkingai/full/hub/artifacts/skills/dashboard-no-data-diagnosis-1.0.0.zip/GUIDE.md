# Dashboard evidence-gap diagnosis

Use when the project can supply a versioned dashboard definition and the underlying governed analysis identity.

1. Resolve the dashboard definition, source analysis, filters, timezone and expected data window.
2. Compare governed source status, completeness and quality with the configured filter and binding expectations.
3. Classify supported empty, stale, permission, binding or contract gaps and leave UI-only causes unverified.

Layout and UI state are not Runtime facts; absent dashboard configuration stops any claim about why the page is empty.
