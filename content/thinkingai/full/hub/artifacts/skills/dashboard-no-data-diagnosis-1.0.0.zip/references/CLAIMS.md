# Claim Policy

## Allowed


## Forbidden

- `causality`
- `dashboard-ui-state`
- `silent-permission-inference`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
