# Payment attribution contract review

Use for a bounded payment window when the project has a reviewed attribution definition.

1. Resolve payment, refund, channel, attribution-window, currency and identity semantics.
2. Use the registered anomaly product on matched returned dimensions with preserved coverage state.
3. Report attributed observations and unresolved allocation assumptions without incrementality claims.

Returned dimension labels cannot define attribution, and descriptive allocation does not prove channel causality.
