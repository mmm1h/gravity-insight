# Claim Policy

## Allowed


## Forbidden

- `causality`
- `complete-attribution`
- `incremental-channel-value`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
