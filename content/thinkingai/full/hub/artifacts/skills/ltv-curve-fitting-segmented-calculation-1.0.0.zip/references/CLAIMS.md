# Claim Policy

## Allowed


## Forbidden

- `causality`
- `invented-confidence`
- `unsupported-segment-extrapolation`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
