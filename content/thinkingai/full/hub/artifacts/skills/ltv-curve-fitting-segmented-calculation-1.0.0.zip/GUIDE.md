# Segmented value-curve fit readiness

Use to assess whether comparable project cohorts can support a bounded segmented value model.

1. Resolve segment, cohort, net-value, currency, censoring and observation-horizon semantics.
2. Verify sample and coverage assumptions plus the exact approved curve Model and calibration evidence.
3. Stop on incompatible units or unsupported horizons; otherwise report estimates with segment-specific limitations.

Segment labels, sparse tails and vendor examples cannot supply missing cohort coverage or validated parameters.
