# Claim Policy

## Allowed


## Forbidden

- `causality`
- `complete-funnel-population`
- `inferred-step-definition`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
