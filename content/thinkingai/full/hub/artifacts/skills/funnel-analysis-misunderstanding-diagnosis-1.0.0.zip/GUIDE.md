# Funnel interpretation contract check

Use when a project supplies the exact ordered event semantics and cohort entry rule.

1. Resolve ordered step events, identity, cohort entry, conversion window and deduplication rules.
2. Apply a reviewed funnel-diagnosis Operator to governed returned steps and preserve partial coverage.
3. Report contract conflicts and returned step loss without inferring unobserved reasons or causal interventions.

Step labels and returned percentages cannot define sequence, denominator or causality; unresolved rules stop interpretation.
