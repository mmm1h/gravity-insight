# Claim Policy

## Allowed


## Forbidden

- `causality`
- `complete-community-population`
- `instruction-authority`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
