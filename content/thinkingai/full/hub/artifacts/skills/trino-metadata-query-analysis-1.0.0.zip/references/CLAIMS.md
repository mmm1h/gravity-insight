# Claim Policy

## Allowed


## Forbidden

- `metadata-completeness`
- `sql-execution-authorized`
- `trino-dialect-supported`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
