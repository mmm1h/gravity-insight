# Trino metadata readiness review

Use to classify a metadata gap for a named catalog, schema and bounded question.

1. Define the catalog, schema, metadata relation, fields and read-only purpose.
2. Check for an exact registered Trino capability with dialect, identity, allowlist and resource budgets.
3. Return the unsupported gap and required evidence; do not route through SQLite or arbitrary SQL.

The SQLite Explorer and generic SQL text do not prove Trino identity, transaction, function or resource controls.
