# Trino 元数据就绪性评审

用于对指定 catalog、schema 和有界问题的元数据缺口进行分类。

1. 定义 catalog、schema、元数据关系、字段和只读目的。
2. 检查是否存在确切的已注册 Trino 能力，并具备方言、身份、允许列表和资源预算。
3. 返回不受支持的缺口和所需证据；不得通过 SQLite 或任意 SQL 路由。

SQLite Explorer 和通用 SQL 文本不能证明 Trino 的身份、事务、函数或资源控制。
