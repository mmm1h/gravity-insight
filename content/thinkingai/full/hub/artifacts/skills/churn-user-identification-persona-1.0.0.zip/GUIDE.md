# Governed churn-segment profile

Use for descriptive segment work when churn and cohort semantics are reviewed and user-level handling is authorized.

1. Resolve the churn event, eligibility window, cohort and allowed profile dimensions.
2. Apply a reviewed segment-profile Operator to governed returned rows with privacy and minimum-sample checks.
3. Separate descriptive traits from hypotheses and suppress unsupported sensitive or causal interpretations.

A profile describes returned members; it cannot reveal unreturned users, sensitive traits or reasons for churn without stronger evidence.
