# Claim Policy

## Allowed


## Forbidden

- `causality`
- `complete-user-population`
- `sensitive-trait-inference`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
