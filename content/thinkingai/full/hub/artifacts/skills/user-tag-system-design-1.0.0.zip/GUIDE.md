# User tag contract proposal

Use when the project can supply authoritative taxonomy, identity and governance requirements.

1. Resolve tag purpose, owner, subject identity, eligible population, inputs, refresh and retention policy.
2. Check semantic conflicts, sensitivity, versioning and measurement requirements against project Context.
3. Return a value-free contract proposal; require separate governed computation and Action preview for membership changes.

Documentation cannot authorize identity joins, membership mutation or sensitive trait derivation.
