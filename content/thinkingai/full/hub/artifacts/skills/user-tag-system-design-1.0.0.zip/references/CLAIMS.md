# Claim Policy

## Allowed


## Forbidden

- `membership-write-authorized`
- `sensitive-trait-inference`
- `tag-population-complete`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
