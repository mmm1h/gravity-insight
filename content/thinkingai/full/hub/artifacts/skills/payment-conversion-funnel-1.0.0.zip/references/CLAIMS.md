# Claim Policy

## Allowed


## Forbidden

- `causality`
- `complete-payment-population`
- `inferred-step-definition`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
