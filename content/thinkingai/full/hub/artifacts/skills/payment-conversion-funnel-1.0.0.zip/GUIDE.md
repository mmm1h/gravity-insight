# Payment conversion path diagnosis

Use when the project has reviewed payment step events and one cohort entry definition.

1. Resolve payment eligibility, ordered steps, identity, conversion window, deduplication and refund rules.
2. Apply a reviewed funnel-diagnosis Operator to governed returned steps and preserve partial coverage.
3. Report observed step loss, exclusions and hypotheses without causal or complete-population claims.

Step names and returned ratios cannot supply missing order or denominator semantics, and loss does not imply cause.
