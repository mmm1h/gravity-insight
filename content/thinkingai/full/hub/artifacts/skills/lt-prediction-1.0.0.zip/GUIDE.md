# Player lifetime readiness assessment

Use to assess forecast readiness for a reviewed acquisition cohort and observation horizon.

1. Resolve cohort entry, activity, churn, censoring and observation-window semantics.
2. Verify the exact lifetime Model lineage, evaluation, approval, expiry and safe horizon.
3. Stop at a model gap unless all requirements hold; otherwise distinguish observations, estimates and assumptions.

Narrative benchmarks and historical examples are not lifetime labels, censoring rules or model validation evidence.
