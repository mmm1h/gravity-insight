# Claim Policy

## Allowed


## Forbidden

- `causality`
- `invented-confidence`
- `unvalidated-lifetime-estimate`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
