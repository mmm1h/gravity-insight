# Claim Policy

## Allowed


## Forbidden

- `causality`
- `incremental-lift`
- `unobserved-campaign-effect`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
