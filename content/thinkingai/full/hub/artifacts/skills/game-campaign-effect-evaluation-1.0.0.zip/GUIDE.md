# Campaign outcome evidence assessment

Use when a campaign definition, outcome metric and non-overlapping comparison design are reviewed.

1. Resolve campaign eligibility, exposure, outcome, guardrail and comparison-window contracts.
2. Align campaign Context with governed observations and apply only a reviewed evaluation Operator.
3. Separate descriptive movement, supported association and experiment-grade evidence with explicit exclusions.

A campaign calendar supports timing only; it does not supply assignment, counterfactuals or causal authorization.
