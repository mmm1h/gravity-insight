# Payment funnel artifact proposal

Use when payment events, identity, ordering and conversion windows are reviewed.

1. Resolve payment eligibility, ordered events, identity, conversion window and refund semantics.
2. Define a target-neutral Analysis Artifact with exact metrics, filters, completeness and claim boundaries.
3. Require a separate governed connector preview, explicit authorization and readback before target creation.

The specification cannot invent events, create a dashboard or authorize any saved-analysis mutation.
