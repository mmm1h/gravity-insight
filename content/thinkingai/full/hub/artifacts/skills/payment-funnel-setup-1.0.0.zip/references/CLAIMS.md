# Claim Policy

## Allowed


## Forbidden

- `dashboard-write-authorized`
- `inferred-step-definition`
- `saved-analysis-created`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
