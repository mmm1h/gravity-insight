# Claim Policy

## Allowed


## Forbidden

- `causality`
- `complete-match-population`
- `matchmaking-fairness`

## Forbidden Without Context

- None beyond the always-forbidden claims above.
