# Competitive outcome observation

Use for a bounded mode, version and participant scope with reviewed competitive semantics.

1. Resolve eligible match, outcome, mode, participant, bracket and version semantics.
2. Query the governed event metric for explicit returned groups and preserve completeness and sample limits.
3. Report observed outcome differences and exclusions without balance, fairness or causal claims.

Returned win rate does not establish balance, matchmaking fairness or player skill without further methods and coverage.
